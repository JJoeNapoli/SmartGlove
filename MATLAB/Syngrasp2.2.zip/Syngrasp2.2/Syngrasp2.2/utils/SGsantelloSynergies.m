function [qm, S] = SGsantello_synergies


S_tmp = load('S_matrix.mat');
S = S_tmp.S;
qm_tmp = load('qm.mat');
qm = qm_tmp.qm;


